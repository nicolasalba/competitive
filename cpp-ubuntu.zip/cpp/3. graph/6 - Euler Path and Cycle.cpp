6. Euler Path and Cycle

// TODO