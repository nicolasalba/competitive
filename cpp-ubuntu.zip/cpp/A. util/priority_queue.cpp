template<class T> using pql = priority_queue<T,vector<T>,greater<T>>;// less
template<class T> using pqg = priority_queue<T>; // greater
