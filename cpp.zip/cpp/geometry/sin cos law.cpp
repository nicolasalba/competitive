a/senA == b/senB == c/senC

c^2 = a^2 + b^2 - 2abcosC
