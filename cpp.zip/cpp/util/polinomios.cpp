A(x) = Sum i=0 to n ( a_i * x^i )  y B(x) Sum i=0 to m ( b_i * x^i)

A(x)*B(x) Sum i=0 to (n+m) Sum j=0 to (n+m)  (a_j)*(b_i-j))x^i
