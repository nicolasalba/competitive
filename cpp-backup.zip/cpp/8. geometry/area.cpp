// Glass Area
// p is the height of water
// r2 the small radio of base
// r3 the big radio of water ceil
((p * PI)*(sq(r1) + sq(r2) + r1 * r2))/3
