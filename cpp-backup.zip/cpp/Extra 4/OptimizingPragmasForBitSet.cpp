#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")

// The difference to TLE and AC in https://cses.fi/problemset/task/2137/
